from distutils.core import setup

setup(
    name='DateMate',
    version='1.0',
    py_modules=['DateMate'],
    ext_modules=[('spam', {'sources': ['spam.pyd']})],
    data_files=[('.', ['검색.png']),
                ('.', ['관광지.png']),
                ('.', ['그래프.png']),
                ('.', ['맛집.png']),
                ('.', ['줌아웃.png']),
                ('.', ['줌인.png']),
                ('.', ['텔레그램.png'])]
)